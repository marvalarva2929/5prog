gcc -o hw3 main.c parse.c argparse.c labletable.c macro.c encode.c
