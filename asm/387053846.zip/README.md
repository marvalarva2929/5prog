Name: Joshua Vigel
EID: jpv865

To compile run ./build.sh and run ./hw3 filename1 filename2 filename3 where the filenames are the input, inermediate output, and binary output respectively.

Test cases are contained in the test.c file.
